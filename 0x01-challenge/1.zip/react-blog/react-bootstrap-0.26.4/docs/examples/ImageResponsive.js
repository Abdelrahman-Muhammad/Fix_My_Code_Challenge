const imageResponsiveInstance = (
  <Image src="/assets/thumbnail.png" responsive />
);

React.render(imageResponsiveInstance, mountNode);
